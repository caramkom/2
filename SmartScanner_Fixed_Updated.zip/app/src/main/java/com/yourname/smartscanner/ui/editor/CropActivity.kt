package com.yourname.smartscanner.ui.editor

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.os.Bundle
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.yourname.smartscanner.R
import com.yourname.smartscanner.databinding.ActivityCropBinding
import com.yourname.smartscanner.utils.ImageProcessor
import org.opencv.core.Point as CvPoint
import java.io.File
import java.io.FileOutputStream

class CropActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCropBinding
    private var originalBitmap: Bitmap? = null
    private var selectedCorner = -1
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ✅ FIXED: Load bitmap from file path instead of Intent extra
        val bitmapPath = intent.getStringExtra("bitmap_path")
        val edgesArray = intent.getSerializableExtra("edges") as? Array<FloatArray>

        if (bitmapPath == null) {
            Toast.makeText(this, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        originalBitmap = BitmapFactory.decodeFile(bitmapPath)
        val bitmap = originalBitmap

        if (bitmap == null) {
            Toast.makeText(this, "تعذر فك تشفير الصورة", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        binding.ivCrop.setImageBitmap(bitmap)
        binding.ivCrop.post {
            computeTransform(bitmap)
            val bitmapCorners = if (edgesArray != null && edgesArray.size == 4) {
                edgesArray.map { PointF(it[0], it[1]) }
            } else {
                listOf(
                    PointF(0f, 0f),
                    PointF(bitmap.width.toFloat(), 0f),
                    PointF(bitmap.width.toFloat(), bitmap.height.toFloat()),
                    PointF(0f, bitmap.height.toFloat())
                )
            }
            binding.cropOverlay.corners = bitmapCorners.map { bitmapToView(it) }.toMutableList()
        }

        binding.btnConfirm.setOnClickListener { confirmCrop() }
        binding.btnAuto.setOnClickListener { autoDetect() }
        binding.btnCancel.setOnClickListener { finish() }

        binding.cropOverlay.setOnTouchListener { _, event -> handleTouch(event); true }

        // Animate buttons
        binding.buttonBar.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up))
    }

    private fun computeTransform(bitmap: Bitmap) {
        val viewWidth = binding.ivCrop.width.toFloat()
        val viewHeight = binding.ivCrop.height.toFloat()
        if (viewWidth <= 0f || viewHeight <= 0f) return
        scale = minOf(viewWidth / bitmap.width, viewHeight / bitmap.height)
        offsetX = (viewWidth - bitmap.width * scale) / 2f
        offsetY = (viewHeight - bitmap.height * scale) / 2f
    }

    private fun bitmapToView(p: PointF) = PointF(p.x * scale + offsetX, p.y * scale + offsetY)
    private fun viewToBitmap(p: PointF) = PointF((p.x - offsetX) / scale, (p.y - offsetY) / scale)

    private fun handleTouch(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> selectedCorner = binding.cropOverlay.nearestCornerIndex(event.x, event.y)
            MotionEvent.ACTION_MOVE -> if (selectedCorner != -1) {
                val updated = binding.cropOverlay.corners.toMutableList()
                updated[selectedCorner] = PointF(
                    event.x.coerceIn(0f, binding.ivCrop.width.toFloat()),
                    event.y.coerceIn(0f, binding.ivCrop.height.toFloat())
                )
                binding.cropOverlay.corners = updated
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> selectedCorner = -1
        }
    }

    private fun autoDetect() {
        val bitmap = originalBitmap ?: return
        val edges = ImageProcessor.detectEdges(bitmap)
        if (edges.size == 4) {
            binding.cropOverlay.corners = edges.map { bitmapToView(PointF(it.x.toFloat(), it.y.toFloat())) }.toMutableList()
            Toast.makeText(this, "تم الاكتشاف التلقائي", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "تعذر الاكتشاف التلقائي، اضبط الزوايا يدويًا", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmCrop() {
        val bitmap = originalBitmap ?: return
        if (binding.cropOverlay.corners.size != 4) return

        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.btnConfirm.isEnabled = false

        val bitmapCorners = binding.cropOverlay.corners.map { viewToBitmap(it) }
        val cvPoints = bitmapCorners.map { CvPoint(it.x.toDouble(), it.y.toDouble()) }

        try {
            val result = ImageProcessor.perspectiveCrop(bitmap, cvPoints)

            // ✅ FIXED: Save result to temp file and return path
            val tempFile = File(cacheDir, "cropped_${System.currentTimeMillis()}.jpg")
            FileOutputStream(tempFile).use { 
                result.compress(Bitmap.CompressFormat.JPEG, 95, it) 
            }

            val intent = Intent().apply { 
                putExtra("cropped_bitmap_path", tempFile.absolutePath) 
            }
            setResult(RESULT_OK, intent)
            finish()
        } catch (e: Exception) {
            binding.progressBar.visibility = android.view.View.GONE
            binding.btnConfirm.isEnabled = true
            Toast.makeText(this, "خطأ في القص: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        originalBitmap?.recycle()
    }
}
