package com.yourname.smartscanner.utils

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object ImageProcessor {

    private const val MAX_DIMENSION = 2480

    fun resizeIfNeeded(bitmap: Bitmap, maxDimension: Int = MAX_DIMENSION): Bitmap {
        val largerSide = max(bitmap.width, bitmap.height)
        if (largerSide <= maxDimension) return bitmap
        val scale = maxDimension.toFloat() / largerSide
        val newWidth = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val newHeight = (bitmap.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    fun detectEdges(bitmap: Bitmap): List<Point> {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        val gray = Mat()
        Imgproc.cvtColor(mat, gray, Imgproc.COLOR_BGR2GRAY)

        val blurred = Mat()
        Imgproc.GaussianBlur(gray, blurred, Size(5.0, 5.0), 0.0)

        val thresh = Mat()
        Imgproc.adaptiveThreshold(blurred, thresh, 255.0, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY, 11, 2.0)

        val edges = Mat()
        Imgproc.Canny(thresh, edges, 50.0, 150.0)

        val contours = ArrayList<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(edges, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val totalArea = mat.rows().toDouble() * mat.cols().toDouble()
        val largest = contours.maxByOrNull { Imgproc.contourArea(it) }
        val largestArea = largest?.let { Imgproc.contourArea(it) } ?: 0.0

        mat.release(); gray.release(); blurred.release(); thresh.release(); edges.release(); hierarchy.release()

        return if (largest != null && largestArea >= totalArea * 0.25) {
            orderCorners(approximateCorners(largest))
        } else defaultCorners(mat)
    }

    private fun orderCorners(points: List<Point>): List<Point> {
        if (points.size != 4) return points
        val bySum = points.sortedBy { it.x + it.y }
        val topLeft = bySum.first()
        val bottomRight = bySum.last()
        val byDiff = points.sortedBy { it.y - it.x }
        val topRight = byDiff.first()
        val bottomLeft = byDiff.last()
        return listOf(topLeft, topRight, bottomRight, bottomLeft)
    }

    fun perspectiveCrop(bitmap: Bitmap, points: List<Point>): Bitmap {
        val srcMat = Mat()
        Utils.bitmapToMat(bitmap, srcMat)
        val srcPoints = MatOfPoint2f(*points.toTypedArray())
        val width = max(distance(points[0], points[1]), distance(points[2], points[3])).toInt()
        val height = max(distance(points[0], points[3]), distance(points[1], points[2])).toInt()
        val dstPoints = MatOfPoint2f(
            Point(0.0, 0.0), 
            Point(width.toDouble(), 0.0), 
            Point(width.toDouble(), height.toDouble()), 
            Point(0.0, height.toDouble())
        )
        val transform = Imgproc.getPerspectiveTransform(srcPoints, dstPoints)
        val dstMat = Mat()
        Imgproc.warpPerspective(srcMat, dstMat, transform, Size(width.toDouble(), height.toDouble()))
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(dstMat, result)
        srcMat.release(); dstMat.release(); transform.release()
        return result
    }

    fun applyFilter(bitmap: Bitmap, filter: FilterType): Bitmap = when (filter) {
        FilterType.ORIGINAL -> bitmap
        FilterType.BLACK_WHITE -> toBlackWhite(bitmap)
        FilterType.GRAYSCALE -> toGrayscale(bitmap)
        FilterType.MAGIC_COLOR -> applyMagicColor(bitmap)
    }

    fun processIdCard(bitmap: Bitmap): Bitmap {
        val edges = detectEdges(bitmap)
        val cropped = perspectiveCrop(bitmap, edges)
        val targetWidth = 1700
        val targetHeight = (targetWidth / 1.586).toInt()
        val scaled = Bitmap.createScaledBitmap(cropped, targetWidth, targetHeight, true)
        val padding = 80
        val result = Bitmap.createBitmap(targetWidth + padding * 2, targetHeight + padding * 2, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(scaled, padding.toFloat(), padding.toFloat(), null)
        return result
    }

    fun createIdCardCombined(front: Bitmap, back: Bitmap): Bitmap {
        val width = max(front.width, back.width)
        val height = front.height + back.height + 100
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(front, (width - front.width) / 2f, 50f, null)
        val paint = Paint().apply { color = Color.LTGRAY; strokeWidth = 2f }
        canvas.drawLine(50f, front.height + 75f, width - 50f, front.height + 75f, paint)
        canvas.drawBitmap(back, (width - back.width) / 2f, front.height + 100f, null)
        return result
    }

    fun autoEnhance(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)

        val lab = Mat()
        Imgproc.cvtColor(mat, lab, Imgproc.COLOR_BGR2Lab)
        val channels = ArrayList<Mat>()
        Core.split(lab, channels)
        val clahe = Imgproc.createCLAHE(2.0, Size(8.0, 8.0))
        clahe.apply(channels[0], channels[0])
        Core.merge(channels, lab)
        Imgproc.cvtColor(lab, mat, Imgproc.COLOR_Lab2BGR)

        val kernel = Mat(3, 3, CvType.CV_32F).apply {
            put(0, 0, 0.0, -1.0, 0.0)
            put(1, 0, -1.0, 5.0, -1.0)
            put(2, 0, 0.0, -1.0, 0.0)
        }
        Imgproc.filter2D(mat, mat, -1, kernel)

        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, result)
        mat.release(); lab.release(); kernel.release()
        return result
    }

    fun autoDeskew(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        val gray = Mat()
        Imgproc.cvtColor(mat, gray, Imgproc.COLOR_BGR2GRAY)

        val edges = Mat()
        Imgproc.Canny(gray, edges, 50.0, 150.0)
        val lines = Mat()
        Imgproc.HoughLinesP(edges, lines, 1.0, Math.PI / 180, 100, 100.0, 10.0)

        var angle = 0.0
        if (lines.rows() > 0) {
            val angles = mutableListOf<Double>()
            for (i in 0 until lines.rows()) {
                val vec = lines.get(i, 0)
                val x1 = vec[0]; val y1 = vec[1]; val x2 = vec[2]; val y2 = vec[3]
                val deg = Math.toDegrees(kotlin.math.atan2(y2 - y1, x2 - x1))
                if (kotlin.math.abs(deg) < 45) angles.add(deg)
            }
            if (angles.isNotEmpty()) angle = angles.average()
        }

        if (kotlin.math.abs(angle) < 0.5) return bitmap

        val center = Point(mat.cols() / 2.0, mat.rows() / 2.0)
        val rotMat = Imgproc.getRotationMatrix2D(center, angle, 1.0)
        val rotated = Mat()
        Imgproc.warpAffine(mat, rotated, rotMat, Size(mat.cols().toDouble(), mat.rows().toDouble()))

        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rotated, result)
        mat.release(); gray.release(); edges.release(); lines.release(); rotMat.release(); rotated.release()
        return result
    }

    private fun toBlackWhite(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_BGR2GRAY)
        Imgproc.threshold(mat, mat, 128.0, 255.0, Imgproc.THRESH_BINARY)
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, result)
        mat.release()
        return result
    }

    private fun toGrayscale(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_BGR2GRAY)
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_GRAY2BGR)
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, result)
        mat.release()
        return result
    }

    private fun applyMagicColor(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        val lab = Mat()
        Imgproc.cvtColor(mat, lab, Imgproc.COLOR_BGR2Lab)
        val channels = ArrayList<Mat>()
        Core.split(lab, channels)
        val clahe = Imgproc.createCLAHE(2.0, Size(8.0, 8.0))
        clahe.apply(channels[0], channels[0])
        Core.merge(channels, lab)
        Imgproc.cvtColor(lab, mat, Imgproc.COLOR_Lab2BGR)
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(mat, result)
        mat.release(); lab.release()
        return result
    }

    private fun approximateCorners(contour: MatOfPoint): List<Point> {
        val approx = MatOfPoint2f()
        val contour2f = MatOfPoint2f(*contour.toArray())
        val peri = Imgproc.arcLength(contour2f, true)
        Imgproc.approxPolyDP(contour2f, approx, 0.02 * peri, true)
        return if (approx.toArray().size == 4) approx.toArray().toList()
        else {
            val rect = Imgproc.minAreaRect(contour2f)
            val box = MatOfPoint2f()
            Imgproc.boxPoints(rect, box)
            box.toArray().toList()
        }
    }

    private fun defaultCorners(mat: Mat): List<Point> {
        val w = mat.cols().toDouble()
        val h = mat.rows().toDouble()
        return listOf(Point(0.0, 0.0), Point(w, 0.0), Point(w, h), Point(0.0, h))
    }

    private fun distance(p1: Point, p2: Point): Double = sqrt((p2.x - p1.x).pow(2.0) + (p2.y - p1.y).pow(2.0))

    enum class FilterType { ORIGINAL, BLACK_WHITE, GRAYSCALE, MAGIC_COLOR }
}
