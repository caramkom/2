package com.yourname.smartscanner.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.yourname.smartscanner.data.local.DocumentDao
import com.yourname.smartscanner.data.local.DocumentEntity
import com.yourname.smartscanner.utils.PdfGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream

class DocumentRepository(
    private val context: Context,
    private val documentDao: DocumentDao
) {
    val allDocuments: Flow<List<DocumentEntity>> = documentDao.getAllDocuments()

    suspend fun saveDocument(
        title: String,
        pages: List<PageData>,
        filterType: String = "ORIGINAL",
        scanMode: String = "DOCUMENT"
    ): Long = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        val docsDir = File(context.getExternalFilesDir(null), "Documents").apply { mkdirs() }

        val originalPaths = JSONArray()
        val processedPaths = JSONArray()
        val processedBitmaps = mutableListOf<Bitmap>()

        pages.forEachIndexed { index, page ->
            val origFile = File(docsDir, "orig_${timestamp}_$index.jpg")
            FileOutputStream(origFile).use {
                page.original.compress(Bitmap.CompressFormat.JPEG, 82, it)
            }
            originalPaths.put(origFile.absolutePath)

            val procFile = File(docsDir, "proc_${timestamp}_$index.jpg")
            FileOutputStream(procFile).use {
                page.processed.compress(Bitmap.CompressFormat.JPEG, 82, it)
            }
            processedPaths.put(procFile.absolutePath)
            processedBitmaps.add(page.processed)
        }

        val pdfPath = PdfGenerator.createPdf(context, processedBitmaps, "doc_$timestamp")

        val entity = DocumentEntity(
            title = title,
            originalPaths = originalPaths.toString(),
            processedPaths = processedPaths.toString(),
            pdfPath = pdfPath,
            pageCount = pages.size,
            filterType = filterType,
            scanMode = scanMode
        )

        documentDao.insert(entity)
    }

    suspend fun deleteDocument(document: DocumentEntity) {
        documentDao.delete(document)
        val originals = JSONArray(document.originalPaths)
        val processed = JSONArray(document.processedPaths)
        for (i in 0 until originals.length()) File(originals.getString(i)).delete()
        for (i in 0 until processed.length()) File(processed.getString(i)).delete()
        document.pdfPath?.let { File(it).delete() }
    }

    fun searchDocuments(query: String): Flow<List<DocumentEntity>> = documentDao.search(query)
    suspend fun updateTitle(id: Long, title: String) = documentDao.updateTitle(id, title)
    suspend fun toggleFavorite(id: Long, current: Boolean) = documentDao.updateFavorite(id, !current)

    data class PageData(val original: Bitmap, val processed: Bitmap)
}