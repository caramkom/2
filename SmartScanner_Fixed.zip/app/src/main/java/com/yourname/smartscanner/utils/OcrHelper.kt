package com.yourname.smartscanner.utils

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

// يستخدم Tesseract4Android بدل ML Kit عشان ML Kit لا يدعم اللغة العربية إطلاقًا.
// اللغات المفعّلة: العربية + الإنجليزية معًا (ara+eng) عشان يقرأ المستندات المختلطة.
class OcrHelper(private val context: Context) {

    private val tessDataDir: File by lazy {
        File(context.filesDir, "tesseract").apply {
            if (!exists()) mkdirs()
        }
    }

    init {
        copyTrainedDataIfNeeded("ara")
        copyTrainedDataIfNeeded("eng")
    }

    private fun copyTrainedDataIfNeeded(lang: String) {
        val tessdataFolder = File(tessDataDir, "tessdata").apply { if (!exists()) mkdirs() }
        val outFile = File(tessdataFolder, "$lang.traineddata")
        if (outFile.exists()) return
        var input: InputStream? = null
        var output: FileOutputStream? = null
        try {
            input = context.assets.open("tessdata/$lang.traineddata")
            output = FileOutputStream(outFile)
            input.copyTo(output)
        } finally {
            input?.close()
            output?.close()
        }
    }

    suspend fun recognize(bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        val tess = TessBaseAPI()
        try {
            val initialized = tess.init(tessDataDir.absolutePath, "ara+eng")
            if (!initialized) return@withContext ""
            tess.setImage(bitmap)
            tess.utF8Text ?: ""
        } finally {
            tess.recycle()
        }
    }

    fun close() {
        // لا حاجة لإغلاق مورد مشترك؛ كل عملية تعرف تُنشئ TessBaseAPI خاص بها وتُحرره فور الانتهاء.
    }
}
