package com.yourname.smartscanner.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val originalPaths: String,
    val processedPaths: String,
    val pdfPath: String?,
    val pageCount: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val ocrText: String? = null,
    val tags: String? = null,
    val isFavorite: Boolean = false,
    val filterType: String = "ORIGINAL",
    val scanMode: String = "DOCUMENT"
)