package com.yourname.smartscanner.ui.editor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View
import kotlin.math.hypot

// طبقة شفافة فوق الـ ImageView بترسم نقاط ومربع القص بإحداثيات الشاشة (view coordinates)
// مباشرة، من غير ما تلمس بيانات البيتماب الأصلي نفسه. ده بيخلي السحب سلس وسريع،
// وبيفصل "إحداثيات العرض" عن "إحداثيات الصورة الحقيقية" بشكل واضح.
class CropOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var corners: MutableList<PointF> = mutableListOf()
        set(value) {
            field = value
            invalidate()
        }

    private val pointPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val linePaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }

    private val cornerRadiusPx = 28f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (corners.size != 4) return
        for (i in 0 until 4) {
            val start = corners[i]
            val end = corners[(i + 1) % 4]
            canvas.drawLine(start.x, start.y, end.x, end.y, linePaint)
        }
        corners.forEach { canvas.drawCircle(it.x, it.y, cornerRadiusPx, pointPaint) }
    }

    fun nearestCornerIndex(x: Float, y: Float, touchSlop: Float = cornerRadiusPx * 2.5f): Int {
        var nearest = -1
        var minDist = Float.MAX_VALUE
        corners.forEachIndexed { index, point ->
            val dist = hypot((x - point.x).toDouble(), (y - point.y).toDouble()).toFloat()
            if (dist < touchSlop && dist < minDist) {
                minDist = dist
                nearest = index
            }
        }
        return nearest
    }
}
