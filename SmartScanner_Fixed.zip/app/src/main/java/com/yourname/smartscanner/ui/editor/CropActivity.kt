package com.yourname.smartscanner.ui.editor

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PointF
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.yourname.smartscanner.R
import com.yourname.smartscanner.utils.ImageProcessor
import org.opencv.core.Point as CvPoint

class CropActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var overlay: CropOverlayView
    private lateinit var btnConfirm: Button
    private lateinit var btnAuto: Button
    private lateinit var btnCancel: Button

    private var originalBitmap: Bitmap? = null
    private var selectedCorner = -1

    // معاملات التحويل بين إحداثيات البيتماب الحقيقي وإحداثيات الشاشة (بسبب scaleType="fitCenter").
    // من غير التحويل ده، سحب الزوايا هيبقى غير دقيق لأن حجم الصورة المعروضة على الشاشة
    // مختلف عن حجمها الحقيقي بالبكسل.
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop)

        imageView = findViewById(R.id.ivCrop)
        overlay = findViewById(R.id.cropOverlay)
        btnConfirm = findViewById(R.id.btnConfirm)
        btnAuto = findViewById(R.id.btnAuto)
        btnCancel = findViewById(R.id.btnCancel)

        originalBitmap = intent.getParcelableExtra("bitmap")
        @Suppress("UNCHECKED_CAST")
        val edges = intent.getSerializableExtra("edges") as? Array<CvPoint>

        val bitmap = originalBitmap
        if (bitmap == null) {
            Toast.makeText(this, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        imageView.setImageBitmap(bitmap)
        imageView.post {
            computeTransform(bitmap)
            val bitmapCorners = if (edges != null && edges.size == 4) {
                edges.map { PointF(it.x.toFloat(), it.y.toFloat()) }
            } else {
                listOf(
                    PointF(0f, 0f),
                    PointF(bitmap.width.toFloat(), 0f),
                    PointF(bitmap.width.toFloat(), bitmap.height.toFloat()),
                    PointF(0f, bitmap.height.toFloat())
                )
            }
            overlay.corners = bitmapCorners.map { bitmapToView(it) }.toMutableList()
        }

        btnConfirm.setOnClickListener { confirmCrop() }
        btnAuto.setOnClickListener { autoDetect() }
        btnCancel.setOnClickListener { finish() }

        overlay.setOnTouchListener { _, event -> handleTouch(event); true }
    }

    private fun computeTransform(bitmap: Bitmap) {
        val viewWidth = imageView.width.toFloat()
        val viewHeight = imageView.height.toFloat()
        if (viewWidth <= 0f || viewHeight <= 0f) return
        scale = minOf(viewWidth / bitmap.width, viewHeight / bitmap.height)
        offsetX = (viewWidth - bitmap.width * scale) / 2f
        offsetY = (viewHeight - bitmap.height * scale) / 2f
    }

    private fun bitmapToView(p: PointF) = PointF(p.x * scale + offsetX, p.y * scale + offsetY)
    private fun viewToBitmap(p: PointF) = PointF((p.x - offsetX) / scale, (p.y - offsetY) / scale)

    private fun handleTouch(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> selectedCorner = overlay.nearestCornerIndex(event.x, event.y)
            MotionEvent.ACTION_MOVE -> if (selectedCorner != -1) {
                val updated = overlay.corners.toMutableList()
                updated[selectedCorner] = PointF(
                    event.x.coerceIn(0f, imageView.width.toFloat()),
                    event.y.coerceIn(0f, imageView.height.toFloat())
                )
                overlay.corners = updated
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> selectedCorner = -1
        }
    }

    private fun autoDetect() {
        val bitmap = originalBitmap ?: return
        val edges = ImageProcessor.detectEdges(bitmap)
        if (edges.size == 4) {
            overlay.corners = edges.map { bitmapToView(PointF(it.x.toFloat(), it.y.toFloat())) }.toMutableList()
        } else {
            Toast.makeText(this, "تعذر الاكتشاف التلقائي، اضبط الزوايا يدويًا", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmCrop() {
        val bitmap = originalBitmap ?: return
        if (overlay.corners.size != 4) return
        val bitmapCorners = overlay.corners.map { viewToBitmap(it) }
        val cvPoints = bitmapCorners.map { CvPoint(it.x.toDouble(), it.y.toDouble()) }
        val result = ImageProcessor.perspectiveCrop(bitmap, cvPoints)
        val intent = Intent().apply { putExtra("cropped_bitmap", result) }
        setResult(RESULT_OK, intent)
        finish()
    }
}
