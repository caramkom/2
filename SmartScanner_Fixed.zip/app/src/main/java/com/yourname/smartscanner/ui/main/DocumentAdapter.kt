package com.yourname.smartscanner.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.yourname.smartscanner.R
import com.yourname.smartscanner.data.local.DocumentEntity
import com.yourname.smartscanner.databinding.ItemDocumentBinding
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

class DocumentAdapter(private val onItemClick: (DocumentEntity) -> Unit, private val onItemLongClick: (View, DocumentEntity) -> Unit) : ListAdapter<DocumentEntity, DocumentAdapter.ViewHolder>(DiffCallback()) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(ItemDocumentBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    inner class ViewHolder(private val binding: ItemDocumentBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(doc: DocumentEntity) {
            binding.tvTitle.text = doc.title
            binding.tvDate.text = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(doc.createdAt))
            binding.tvPages.text = "${doc.pageCount} صفحة"
            val paths = JSONArray(doc.processedPaths)
            val firstImage = if (paths.length() > 0) paths.getString(0) else doc.originalPaths
            Glide.with(binding.root).load(firstImage).placeholder(R.drawable.ic_document).centerCrop().into(binding.ivThumbnail)
            binding.tvBadge.text = if (doc.scanMode == "ID_CARD") "🪪" else "📄"
            binding.tvBadge.visibility = View.VISIBLE
            binding.ivFavorite.visibility = if (doc.isFavorite) View.VISIBLE else View.GONE
            binding.root.setOnClickListener { onItemClick(doc) }
            binding.root.setOnLongClickListener { onItemLongClick(it, doc); true }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<DocumentEntity>() {
        override fun areItemsTheSame(old: DocumentEntity, new: DocumentEntity) = old.id == new.id
        override fun areContentsTheSame(old: DocumentEntity, new: DocumentEntity) = old == new
    }
}