package com.yourname.smartscanner.ui.viewer

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.github.barteksc.pdfviewer.PDFView
import com.yourname.smartscanner.databinding.ActivityPdfViewerBinding
import java.io.File

class PdfViewerActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPdfViewerBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val pdfPath = intent.getStringExtra("pdf_path")
        binding.toolbar.title = intent.getStringExtra("title") ?: "مستند"
        binding.toolbar.setNavigationOnClickListener { finish() }
        if (pdfPath != null && File(pdfPath).exists()) binding.pdfView.fromFile(File(pdfPath)).enableSwipe(true).swipeHorizontal(false).enableDoubletap(true).load()
        else { Toast.makeText(this, "الملف غير موجود", Toast.LENGTH_SHORT).show(); finish() }
    }
}