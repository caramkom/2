package com.yourname.smartscanner.ui.editor

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yourname.smartscanner.R
import com.yourname.smartscanner.data.local.AppDatabase
import com.yourname.smartscanner.data.repository.DocumentRepository
import com.yourname.smartscanner.databinding.ActivityMultiPageReviewBinding
import com.yourname.smartscanner.ui.main.MainActivity
import com.yourname.smartscanner.utils.ImageProcessor
import com.yourname.smartscanner.utils.OcrHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class MultiPageReviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMultiPageReviewBinding
    private val pages = mutableListOf<PageItem>()
    private lateinit var adapter: PageReviewAdapter
    private lateinit var repository: DocumentRepository
    private lateinit var ocrHelper: OcrHelper
    private var scanMode = "DOCUMENT"
    private var currentFilter = ImageProcessor.FilterType.ORIGINAL

    data class PageItem(var bitmap: Bitmap, var filter: ImageProcessor.FilterType = ImageProcessor.FilterType.ORIGINAL)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMultiPageReviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bitmaps = intent.getParcelableArrayListExtra<Bitmap>("pages") ?: listOf()
        scanMode = intent.getStringExtra("scan_mode") ?: "DOCUMENT"
        pages.addAll(bitmaps.map { PageItem(it) })

        val db = AppDatabase.getDatabase(this)
        repository = DocumentRepository(this, db.documentDao())
        ocrHelper = OcrHelper(this)

        setupRecyclerView()
        setupButtons()
        updateUI()
    }

    private fun setupRecyclerView() {
        adapter = PageReviewAdapter(pages, onDelete = { deletePage(it) }, onEdit = { editPage(it) })
        binding.recyclerPages.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.recyclerPages.adapter = adapter
        val itemTouchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                val from = viewHolder.adapterPosition; val to = target.adapterPosition
                Collections.swap(pages, from, to); adapter.notifyItemMoved(from, to); return true
            }
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        itemTouchHelper.attachToRecyclerView(binding.recyclerPages)
    }

    private fun setupButtons() {
        binding.btnBack.setOnClickListener { finish() }
        binding.btnOriginal.setOnClickListener { applyFilterToAll(ImageProcessor.FilterType.ORIGINAL) }
        binding.btnMagic.setOnClickListener { applyFilterToAll(ImageProcessor.FilterType.MAGIC_COLOR) }
        binding.btnBw.setOnClickListener { applyFilterToAll(ImageProcessor.FilterType.BLACK_WHITE) }
        binding.btnGray.setOnClickListener { applyFilterToAll(ImageProcessor.FilterType.GRAYSCALE) }
        binding.btnAddPage.setOnClickListener { startActivity(Intent(this, com.yourname.smartscanner.ui.camera.CameraActivity::class.java)); finish() }
        binding.btnOcr.setOnClickListener { if (pages.isNotEmpty()) performOcr(pages[0].bitmap) }
        binding.btnSave.setOnClickListener { showSaveDialog() }
    }

    private fun applyFilterToAll(filter: ImageProcessor.FilterType) {
        currentFilter = filter; binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.Default) {
            pages.forEach { it.bitmap = ImageProcessor.applyFilter(it.bitmap, filter); it.filter = filter }
            withContext(Dispatchers.Main) { adapter.notifyDataSetChanged(); binding.progressBar.visibility = View.GONE }
        }
    }

    private fun deletePage(position: Int) {
        if (pages.size <= 1) { Toast.makeText(this, "لا يمكن حذف آخر صفحة", Toast.LENGTH_SHORT).show(); return }
        pages.removeAt(position); adapter.notifyItemRemoved(position); updateUI()
    }

    private fun editPage(position: Int) { Toast.makeText(this, "تعديل الصفحة ${position + 1}", Toast.LENGTH_SHORT).show() }

    private fun performOcr(bitmap: Bitmap) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.Default) {
            try {
                val text = ocrHelper.recognize(bitmap)
                withContext(Dispatchers.Main) { binding.progressBar.visibility = View.GONE; showOcrResult(text) }
            } catch (e: Exception) { withContext(Dispatchers.Main) { binding.progressBar.visibility = View.GONE; Toast.makeText(this@MultiPageReviewActivity, "فشل OCR", Toast.LENGTH_SHORT).show() } }
        }
    }

    private fun showOcrResult(text: String) {
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("النص المستخرج").setMessage(text.ifBlank { "لم يتم العثور على نص" })
            .setPositiveButton("نسخ") { _, _ ->
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("OCR", text))
                Toast.makeText(this, "تم النسخ!", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إغلاق", null).show()
    }

    private fun showSaveDialog() {
        val editText = android.widget.EditText(this).apply { hint = "اسم المستند"; setText("مستند_${System.currentTimeMillis()}") }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("حفظ المستند (${pages.size} صفحة)").setView(editText)
            .setPositiveButton("حفظ") { _, _ -> saveDocument(editText.text.toString().ifBlank { "مستند" }) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun saveDocument(title: String) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val pageDataList = pages.map { DocumentRepository.PageData(it.bitmap, it.bitmap) }
                repository.saveDocument(title = title, pages = pageDataList, filterType = currentFilter.name, scanMode = scanMode)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@MultiPageReviewActivity, "تم حفظ $title (${pages.size} صفحة)!", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@MultiPageReviewActivity, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_CLEAR_TOP })
                    finish()
                }
            } catch (e: Exception) { withContext(Dispatchers.Main) { binding.progressBar.visibility = View.GONE; Toast.makeText(this@MultiPageReviewActivity, "خطأ: ${e.message}", Toast.LENGTH_LONG).show() } }
        }
    }

    private fun updateUI() { binding.tvPageCount.text = "${pages.size} صفحة"; binding.tvPageCount.visibility = View.VISIBLE }
    override fun onDestroy() { super.onDestroy(); ocrHelper.close() }

    inner class PageReviewAdapter(private val pages: List<PageItem>, private val onDelete: (Int) -> Unit, private val onEdit: (Int) -> Unit) : RecyclerView.Adapter<PageReviewAdapter.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_page_review, parent, false))
        override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(pages[position], position)
        override fun getItemCount() = pages.size
        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val ivPage: ImageView = itemView.findViewById(R.id.ivPage)
            private val tvPageNum: TextView = itemView.findViewById(R.id.tvPageNum)
            private val btnDelete: View = itemView.findViewById(R.id.btnDelete)
            fun bind(page: PageItem, position: Int) { ivPage.setImageBitmap(page.bitmap); tvPageNum.text = "${position + 1}"; btnDelete.setOnClickListener { onDelete(position) }; itemView.setOnClickListener { onEdit(position) } }
        }
    }
}