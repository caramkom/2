package com.yourname.smartscanner.ui.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.yourname.smartscanner.databinding.ActivityCameraBinding
import com.yourname.smartscanner.ui.editor.CropActivity
import com.yourname.smartscanner.ui.editor.MultiPageReviewActivity
import com.yourname.smartscanner.utils.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class CameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraBinding
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private val capturedPages = mutableListOf<Bitmap>()
    private var scanMode = ScanMode.DOCUMENT
    private var idCardStep = IdCardStep.NONE
    private var frontCardBitmap: Bitmap? = null

    enum class ScanMode { DOCUMENT, ID_CARD }
    enum class IdCardStep { NONE, FRONT, BACK, DONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        scanMode = (intent.getSerializableExtra("scan_mode") as? ScanMode) ?: ScanMode.DOCUMENT

        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)

        cameraExecutor = Executors.newSingleThreadExecutor()
        setupUI()
    }

    private fun setupUI() {
        binding.btnCapture.setOnClickListener { takePhoto() }
        binding.btnFlash.setOnClickListener { toggleFlash() }
        binding.btnClose.setOnClickListener { finish() }
        if (scanMode == ScanMode.ID_CARD) { idCardStep = IdCardStep.FRONT; updateIdCardUI() }
        binding.btnDone.setOnClickListener { finishScanning() }
        binding.btnRetake.setOnClickListener { retakeLast() }
    }

    private fun updateIdCardUI() {
        when (idCardStep) {
            IdCardStep.FRONT -> { binding.tvMode.text = "📷 وجه البطاقة"; binding.tvHint.text = "ضع البطاقة في الإطار واضغط التقاط" }
            IdCardStep.BACK -> { binding.tvMode.text = "📷 ظهر البطاقة"; binding.tvHint.text = "اقلب البطاقة واضغط التقاط" }
            else -> {}
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.viewFinder.surfaceProvider) }
            val screenAspectRatio = AspectRatio.RATIO_16_9
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flashMode)
                .setTargetAspectRatio(screenAspectRatio)
                .build()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (e: Exception) { Log.e(TAG, "Use case binding failed", e) }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val imageCapture = imageCapture ?: return
        binding.progressBar.visibility = View.VISIBLE
        imageCapture.takePicture(ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    lifecycleScope.launch {
                        val rawBitmap = imageProxyToBitmap(image)
                        image.close()
                        val bitmap = withContext(Dispatchers.Default) { ImageProcessor.resizeIfNeeded(rawBitmap) }
                        processCapturedImage(bitmap)
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    binding.progressBar.visibility = View.GONE
                    Toast.makeText(this@CameraActivity, "فشل الالتقاط: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private suspend fun processCapturedImage(bitmap: Bitmap) {
        withContext(Dispatchers.Default) {
            try {
                when (scanMode) {
                    ScanMode.ID_CARD -> {
                        val processed = when (idCardStep) {
                            IdCardStep.FRONT -> {
                                frontCardBitmap = ImageProcessor.processIdCard(bitmap)
                                withContext(Dispatchers.Main) {
                                    idCardStep = IdCardStep.BACK; updateIdCardUI(); binding.progressBar.visibility = View.GONE
                                    Toast.makeText(this@CameraActivity, "تم التقاط الوجه، الآن اقلب البطاقة", Toast.LENGTH_LONG).show()
                                }
                                return@withContext
                            }
                            IdCardStep.BACK -> {
                                val backBitmap = ImageProcessor.processIdCard(bitmap)
                                capturedPages.add(ImageProcessor.createIdCardCombined(frontCardBitmap!!, backBitmap))
                                withContext(Dispatchers.Main) { idCardStep = IdCardStep.DONE; finishScanning() }
                                return@withContext
                            }
                            else -> return@withContext
                        }
                        capturedPages.add(processed)
                        withContext(Dispatchers.Main) {
                            binding.progressBar.visibility = View.GONE
                            updatePageCounter()
                        }
                    }
                    ScanMode.DOCUMENT -> {
                        // الذهاب لشاشة تعديل الحواف يدويًا بدلاً من القص التلقائي المباشر،
                        // عشان المستخدم يقدر يصحح الاكتشاف لو غلط بدل ما يبان "زوم" غير مضبوط.
                        val edges = ImageProcessor.detectEdges(bitmap)
                        withContext(Dispatchers.Main) {
                            binding.progressBar.visibility = View.GONE
                            val intent = Intent(this@CameraActivity, CropActivity::class.java).apply {
                                putExtra("bitmap", bitmap)
                                putExtra("edges", edges.toTypedArray())
                            }
                            startActivityForResult(intent, CROP_REQUEST_CODE)
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { binding.progressBar.visibility = View.GONE; Toast.makeText(this@CameraActivity, "خطأ في المعالجة", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CROP_REQUEST_CODE && resultCode == RESULT_OK) {
            val croppedBitmap = data?.getParcelableExtra<Bitmap>("cropped_bitmap")
            croppedBitmap?.let {
                capturedPages.add(it)
                updatePageCounter()
                Toast.makeText(this, "تمت إضافة صفحة ${capturedPages.size}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updatePageCounter() {
        binding.tvPageCount.text = "${capturedPages.size} صفحة"
        binding.tvPageCount.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
        binding.btnDone.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
        binding.btnRetake.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
    }

    private fun retakeLast() {
        if (capturedPages.isNotEmpty()) { capturedPages.removeAt(capturedPages.size - 1); updatePageCounter(); Toast.makeText(this, "تم حذف آخر صفحة", Toast.LENGTH_SHORT).show() }
    }

    private fun finishScanning() {
        if (capturedPages.isEmpty() && scanMode != ScanMode.ID_CARD) { Toast.makeText(this, "لم تقم بمسح أي صفحة", Toast.LENGTH_SHORT).show(); return }
        val intent = Intent(this, MultiPageReviewActivity::class.java).apply {
            putParcelableArrayListExtra("pages", ArrayList(capturedPages))
            putExtra("scan_mode", scanMode.name)
        }
        startActivity(intent); finish()
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IllegalStateException("Failed to decode bitmap")
    }

    private fun toggleFlash() {
        flashMode = when (flashMode) { ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON; ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO; else -> ImageCapture.FLASH_MODE_OFF }
        imageCapture?.flashMode = flashMode
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all { ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) { if (allPermissionsGranted()) startCamera() else { Toast.makeText(this, "الأذونات مطلوبة", Toast.LENGTH_SHORT).show(); finish() } }
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }

    companion object { private const val TAG = "CameraActivity"; private const val REQUEST_CODE_PERMISSIONS = 10; private const val CROP_REQUEST_CODE = 100; private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA) }
}