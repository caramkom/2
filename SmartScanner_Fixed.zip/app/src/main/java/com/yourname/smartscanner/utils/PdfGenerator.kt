package com.yourname.smartscanner.utils

import android.content.Context
import android.graphics.Bitmap
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Image
import com.itextpdf.io.image.ImageDataFactory
import java.io.ByteArrayOutputStream
import java.io.File

object PdfGenerator {
    fun createPdf(context: Context, pages: List<Bitmap>, fileName: String): String {
        val pdfDir = File(context.getExternalFilesDir(null), "PDFs").apply { mkdirs() }
        val pdfFile = File(pdfDir, "$fileName.pdf")
        PdfWriter(pdfFile.absolutePath).use { writer ->
            val pdfDoc = PdfDocument(writer)
            val document = Document(pdfDoc)
            pages.forEachIndexed { index, bitmap ->
                val baos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                val imageData = ImageDataFactory.create(baos.toByteArray())
                val image = Image(imageData)
                val pageSize = PageSize.A4
                val scale = minOf((pageSize.width - 72) / image.imageWidth, (pageSize.height - 72) / image.imageHeight)
                image.scale(scale, scale)
                document.add(image)
                if (index < pages.size - 1) pdfDoc.addNewPage()
            }
            document.close()
        }
        return pdfFile.absolutePath
    }
}