package com.yourname.smartscanner

import android.app.Application
import org.opencv.android.OpenCVLoader

class ScannerApp : Application() {
    override fun onCreate() { super.onCreate(); OpenCVLoader.initDebug() }
}