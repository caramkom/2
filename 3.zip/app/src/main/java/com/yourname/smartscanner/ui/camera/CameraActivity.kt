package com.yourname.smartscanner.ui.camera

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.yourname.smartscanner.R
import com.yourname.smartscanner.databinding.ActivityCameraBinding
import com.yourname.smartscanner.ui.editor.CropActivity
import com.yourname.smartscanner.ui.editor.MultiPageReviewActivity
import com.yourname.smartscanner.utils.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

class CameraActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCameraBinding
    private var imageCapture: ImageCapture? = null
    private lateinit var cameraExecutor: ExecutorService
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private val capturedPages = mutableListOf<Bitmap>()
    private var scanMode = ScanMode.DOCUMENT
    private var idCardStep = IdCardStep.NONE
    private var frontCardBitmap: Bitmap? = null
    private var isProcessing = false

    @Parcelize
    enum class ScanMode : Parcelable { DOCUMENT, ID_CARD }
    enum class IdCardStep { NONE, FRONT, BACK, DONE }

    companion object {
        private const val TAG = "CameraActivity"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }

    // ✅ FIXED: Use ActivityResultContracts instead of deprecated startActivityForResult
    private val cropLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val croppedPath = result.data?.getStringExtra("cropped_bitmap_path")
            croppedPath?.let { path ->
                val croppedBitmap = BitmapFactory.decodeFile(path)
                croppedBitmap?.let {
                    capturedPages.add(it)
                    updatePageCounter()
                    Toast.makeText(this, "تمت إضافة صفحة ${capturedPages.size}", Toast.LENGTH_SHORT).show()
                    // Clean up temp file
                    File(path).delete()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ✅ FIXED: Use getParcelableExtra with Parcelize
        scanMode = intent.getParcelableExtra("scan_mode") ?: ScanMode.DOCUMENT

        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)

        cameraExecutor = Executors.newSingleThreadExecutor()
        setupUI()
    }

    private fun setupUI() {
        binding.btnCapture.setOnClickListener { 
            if (!isProcessing) takePhoto() 
        }
        binding.btnFlash.setOnClickListener { toggleFlash() }
        binding.btnClose.setOnClickListener { finish() }

        if (scanMode == ScanMode.ID_CARD) { 
            idCardStep = IdCardStep.FRONT; 
            updateIdCardUI() 
        }

        binding.btnDone.setOnClickListener { finishScanning() }
        binding.btnRetake.setOnClickListener { retakeLast() }

        // Animate UI elements
        binding.topBar.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_down))
        binding.bottomBar.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up))
    }

    private fun updateIdCardUI() {
        when (idCardStep) {
            IdCardStep.FRONT -> { 
                binding.tvMode.text = "وجه البطاقة" 
                binding.tvHint.text = "ضع البطاقة في الإطار واضغط التقاط"
                binding.ivIdCardGuide.setImageResource(R.drawable.ic_id_card_front)
            }
            IdCardStep.BACK -> { 
                binding.tvMode.text = "ظهر البطاقة" 
                binding.tvHint.text = "اقلب البطاقة واضغط التقاط"
                binding.ivIdCardGuide.setImageResource(R.drawable.ic_id_card_back)
            }
            else -> {}
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder()
                    .build()
                    .also { it.setSurfaceProvider(binding.viewFinder.surfaceProvider) }

                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode)
                    .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .build()

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)

            } catch (e: Exception) { 
                Log.e(TAG, "Use case binding failed", e) 
                Toast.makeText(this, "فشل تشغيل الكاميرا", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        if (isProcessing) return
        val imageCapture = imageCapture ?: return

        isProcessing = true
        binding.progressBar.visibility = View.VISIBLE
        binding.btnCapture.isEnabled = false

        // Shutter animation
        binding.shutterEffect.visibility = View.VISIBLE
        binding.shutterEffect.animate().alpha(0f).setDuration(200).withEndAction {
            binding.shutterEffect.alpha = 1f
            binding.shutterEffect.visibility = View.GONE
        }.start()

        imageCapture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    lifecycleScope.launch(Dispatchers.Default) {
                        try {
                            val rawBitmap = imageProxyToBitmap(image)
                            image.close()

                            val resizedBitmap = ImageProcessor.resizeIfNeeded(rawBitmap)
                            if (rawBitmap != resizedBitmap && rawBitmap.isRecycled.not()) {
                                rawBitmap.recycle()
                            }

                            processCapturedImage(resizedBitmap)
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                binding.progressBar.visibility = View.GONE
                                binding.btnCapture.isEnabled = true
                                isProcessing = false
                                Toast.makeText(this@CameraActivity, "خطأ في المعالجة: ${e.message}", Toast.LENGTH_SHORT).show()
                                Log.e(TAG, "Processing error", e)
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    binding.progressBar.visibility = View.GONE
                    binding.btnCapture.isEnabled = true
                    isProcessing = false
                    Toast.makeText(this@CameraActivity, "فشل الالتقاط: ${exception.message}", Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "Capture error", exception)
                }
            }
        )
    }

    // ✅ FIXED: Proper YUV to Bitmap conversion (was causing "خطأ في المعالجة")
    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        return when (image.format) {
            ImageFormat.JPEG -> {
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalStateException("Failed to decode JPEG")
            }
            ImageFormat.YUV_420_888 -> {
                val yBuffer = image.planes[0].buffer
                val uBuffer = image.planes[1].buffer
                val vBuffer = image.planes[2].buffer

                val ySize = yBuffer.remaining()
                val uSize = uBuffer.remaining()
                val vSize = vBuffer.remaining()

                val nv21 = ByteArray(ySize + uSize + vSize)

                yBuffer.get(nv21, 0, ySize)
                vBuffer.get(nv21, ySize, vSize)
                uBuffer.get(nv21, ySize + vSize, uSize)

                val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
                val out = ByteArrayOutputStream()
                yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 95, out)
                val imageBytes = out.toByteArray()

                BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                    ?: throw IllegalStateException("Failed to decode YUV")
            }
            else -> throw IllegalStateException("Unsupported image format: ${image.format}")
        }
    }

    private suspend fun processCapturedImage(bitmap: Bitmap) {
        withContext(Dispatchers.Default) {
            try {
                when (scanMode) {
                    ScanMode.ID_CARD -> {
                        when (idCardStep) {
                            IdCardStep.FRONT -> {
                                frontCardBitmap = ImageProcessor.processIdCard(bitmap)
                                withContext(Dispatchers.Main) {
                                    idCardStep = IdCardStep.BACK
                                    updateIdCardUI()
                                    binding.progressBar.visibility = View.GONE
                                    binding.btnCapture.isEnabled = true
                                    isProcessing = false
                                    Toast.makeText(this@CameraActivity, "تم التقاط الوجه، الآن اقلب البطاقة", Toast.LENGTH_LONG).show()
                                }
                                return@withContext
                            }
                            IdCardStep.BACK -> {
                                val backBitmap = ImageProcessor.processIdCard(bitmap)
                                val combined = ImageProcessor.createIdCardCombined(frontCardBitmap!!, backBitmap)
                                capturedPages.add(combined)
                                withContext(Dispatchers.Main) { 
                                    idCardStep = IdCardStep.DONE
                                    finishScanning() 
                                }
                                return@withContext
                            }
                            else -> return@withContext
                        }
                    }
                    ScanMode.DOCUMENT -> {
                        val edges = ImageProcessor.detectEdges(bitmap)
                        withContext(Dispatchers.Main) {
                            binding.progressBar.visibility = View.GONE
                            binding.btnCapture.isEnabled = true
                            isProcessing = false

                            // ✅ FIXED: Save bitmap to temp file instead of passing via Intent
                            val tempFile = File(cacheDir, "temp_capture_${System.currentTimeMillis()}.jpg")
                            FileOutputStream(tempFile).use { 
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) 
                            }

                            val intent = Intent(this@CameraActivity, CropActivity::class.java).apply {
                                putExtra("bitmap_path", tempFile.absolutePath)
                                putExtra("edges", edges.map { floatArrayOf(it.x.toFloat(), it.y.toFloat()) }.toTypedArray())
                            }
                            cropLauncher.launch(intent)
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { 
                    binding.progressBar.visibility = View.GONE
                    binding.btnCapture.isEnabled = true
                    isProcessing = false
                    Toast.makeText(this@CameraActivity, "خطأ في المعالجة: ${e.message}", Toast.LENGTH_SHORT).show()
                    Log.e(TAG, "Processing error", e)
                }
            }
        }
    }

    private fun updatePageCounter() {
        binding.tvPageCount.text = "${capturedPages.size} صفحة"
        binding.tvPageCount.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
        binding.btnDone.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
        binding.btnRetake.visibility = if (capturedPages.size > 0) View.VISIBLE else View.GONE
    }

    private fun retakeLast() {
        if (capturedPages.isNotEmpty()) { 
            capturedPages.removeAt(capturedPages.size - 1)
            // Recycle bitmap to free memory
            updatePageCounter()
            Toast.makeText(this, "تم حذف آخر صفحة", Toast.LENGTH_SHORT).show() 
        }
    }

    private fun finishScanning() {
        if (capturedPages.isEmpty() && scanMode != ScanMode.ID_CARD) { 
            Toast.makeText(this, "لم تقم بمسح أي صفحة", Toast.LENGTH_SHORT).show()
            return 
        }

        // ✅ FIXED: Save all pages to temp files instead of passing via Intent
        val tempPaths = ArrayList<String>()
        capturedPages.forEachIndexed { index, bitmap ->
            val tempFile = File(cacheDir, "temp_page_${System.currentTimeMillis()}_$index.jpg")
            FileOutputStream(tempFile).use { 
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) 
            }
            tempPaths.add(tempFile.absolutePath)
        }

        val intent = Intent(this, MultiPageReviewActivity::class.java).apply {
            putStringArrayListExtra("page_paths", tempPaths)
            putExtra("scan_mode", scanMode.name)
        }
        startActivity(intent)
        finish()
    }

    private fun toggleFlash() {
        flashMode = when (flashMode) { 
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
            ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_AUTO
            else -> ImageCapture.FLASH_MODE_OFF 
        }
        imageCapture?.flashMode = flashMode

        val iconRes = when (flashMode) {
            ImageCapture.FLASH_MODE_ON -> R.drawable.ic_flash_on
            ImageCapture.FLASH_MODE_AUTO -> R.drawable.ic_flash_auto
            else -> R.drawable.ic_flash_off
        }
        binding.btnFlash.setImageResource(iconRes)
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) startCamera()
            else {
                Toast.makeText(this, "الكاميرا مطلوبة للعمل", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        // Clean up temp files
        cacheDir.listFiles()?.filter { it.name.startsWith("temp_") }?.forEach { it.delete() }
    }
}
