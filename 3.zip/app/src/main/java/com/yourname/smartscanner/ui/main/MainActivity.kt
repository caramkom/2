package com.yourname.smartscanner.ui.main

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.yourname.smartscanner.R
import com.yourname.smartscanner.data.local.AppDatabase
import com.yourname.smartscanner.data.local.DocumentEntity
import com.yourname.smartscanner.data.repository.DocumentRepository
import com.yourname.smartscanner.databinding.ActivityMainBinding
import com.yourname.smartscanner.ui.camera.CameraActivity
import com.yourname.smartscanner.ui.viewer.PdfViewerActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: DocumentRepository
    private lateinit var adapter: DocumentAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val db = AppDatabase.getDatabase(this)
        repository = DocumentRepository(this, db.documentDao())
        setupRecyclerView(); setupSearch(); setupButtons(); loadDocuments()
    }

    private fun setupRecyclerView() {
        adapter = DocumentAdapter(onItemClick = { openDocument(it) }, onItemLongClick = { view, doc -> showPopupMenu(view, doc) })
        binding.recyclerView.layoutManager = GridLayoutManager(this, 2)
        binding.recyclerView.adapter = adapter
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean { if (newText.isNullOrBlank()) loadDocuments() else searchDocuments(newText); return true }
        })
    }

    private fun setupButtons() { binding.fabScan.setOnClickListener { showScanOptions() } }

    private fun showScanOptions() {
        val options = arrayOf("📄 مسح مستند", "🪪 مسح بطاقة هوية")
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("اختر وضع المسح").setItems(options) { _, which ->
            when (which) { 0 -> startScan(CameraActivity.ScanMode.DOCUMENT); 1 -> startScan(CameraActivity.ScanMode.ID_CARD) }
        }.show()
    }

    private fun startScan(mode: CameraActivity.ScanMode) { startActivity(Intent(this, CameraActivity::class.java).apply { putExtra("scan_mode", mode as android.os.Parcelable) }) }

    private fun loadDocuments() {
        lifecycleScope.launch { repository.allDocuments.collectLatest { adapter.submitList(it); binding.emptyView.visibility = if (it.isEmpty()) View.VISIBLE else View.GONE } }
    }

    private fun searchDocuments(query: String) { lifecycleScope.launch { repository.searchDocuments(query).collectLatest { adapter.submitList(it) } } }

    private fun openDocument(doc: DocumentEntity) { startActivity(Intent(this, PdfViewerActivity::class.java).apply { putExtra("pdf_path", doc.pdfPath); putExtra("title", doc.title) }) }

    private fun showPopupMenu(view: View, doc: DocumentEntity) {
        PopupMenu(this, view).apply {
            menuInflater.inflate(R.menu.document_menu, menu)
            setOnMenuItemClickListener { when (it.itemId) { R.id.action_share -> shareDocument(doc); R.id.action_rename -> showRenameDialog(doc); R.id.action_delete -> deleteDocument(doc); R.id.action_favorite -> toggleFavorite(doc) }; true }
            show()
        }
    }

    private fun shareDocument(doc: DocumentEntity) {
        val options = arrayOf("📄 مشاركة كـ PDF", "🖼️ مشاركة كصور")
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("اختر طريقة المشاركة").setItems(options) { _, which ->
            when (which) { 0 -> sharePdf(doc); 1 -> shareImages(doc) }
        }.show()
    }

    private fun sharePdf(doc: DocumentEntity) {
        doc.pdfPath?.let { path ->
            val file = java.io.File(path)
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.provider", file)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "مشاركة المستند"))
        }
    }

    private fun shareImages(doc: DocumentEntity) {
        val paths = org.json.JSONArray(doc.processedPaths)
        if (paths.length() == 0) return
        val uris = ArrayList<android.os.Parcelable>()
        for (i in 0 until paths.length()) {
            val file = java.io.File(paths.getString(i))
            if (file.exists()) {
                uris.add(androidx.core.content.FileProvider.getUriForFile(this, "${packageName}.provider", file))
            }
        }
        if (uris.isEmpty()) return
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/jpeg"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "مشاركة الصور"))
    }

    private fun showRenameDialog(doc: DocumentEntity) {
        val editText = android.widget.EditText(this).apply { setText(doc.title) }
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("إعادة التسمية").setView(editText)
            .setPositiveButton("حفظ") { _, _ -> val newName = editText.text.toString(); if (newName.isNotBlank()) lifecycleScope.launch { repository.updateTitle(doc.id, newName) } }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun deleteDocument(doc: DocumentEntity) {
        androidx.appcompat.app.AlertDialog.Builder(this).setTitle("حذف المستند").setMessage("هل أنت متأكد من حذف «${doc.title}»؟")
            .setPositiveButton("حذف") { _, _ -> lifecycleScope.launch { repository.deleteDocument(doc) } }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun toggleFavorite(doc: DocumentEntity) { lifecycleScope.launch { repository.toggleFavorite(doc.id, doc.isFavorite) } }
}